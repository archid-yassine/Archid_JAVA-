package dao;

public interface IDao {
     double getdata();
}
