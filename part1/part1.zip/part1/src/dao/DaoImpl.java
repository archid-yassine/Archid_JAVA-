package dao;

public class DaoImpl implements IDao {
    @Override
    public double getdata() {
        /*
        se connecter à la bd pour récupérer la température
         */
        double temp=Math.random()*40;
        return 0;
    }
}
